package atividadei;

/**
 *
 */
public class AtividadeI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello World !!!");
    }
    
}
