# SI400
O sistema visa solucionar os problemas de uma clínica veterinária, visto no gerenciamento de seus clientes, consultas, animais e veterinários. A clínica possui dificuldades no controle de cadastros de clientes e animais, além dos registros de históricos, consultas e exames. O sistema fará este gerenciamento, tais como, agendamentos de consultas, atualizações cadastrais, histórico de tratamento de animais, informações de sintomas, controle de acesso, agendamento de exames, histórico de consultas.

Componentes do grupo:
Amadeu Carvalho, Alex Rafael, Thiago Henrique Viotto

Repository who have the projects in the discipline SI400 POOII (Programação Orientada a Objetos II or Object Oriented Programming II)
