/*
 * Disciplina: Programação Orientada Objetos 2 
 * Prof.Dr.Ivan Ricarte
 * Curso: Tec.Análise e Desenvolvimento de Sistemas
 */
package br.ftunicamp.veterinaria.control;

import br.ftunicamp.veterinaria.dao.ClienteDAO;
import br.ftunicamp.veterinaria.dao.MySqlDAO;
import br.ftunicamp.veterinaria.model.Cliente;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author AmadeuCarvalho
 */
public class ClienteControle {

    public void insertCliente(String nome, String cpf, String endereco, String telefone, String cep, String email) {
        try {
            ClienteDAO.getInstance().insertCliente(nome, cpf, endereco, telefone, cep, email);
        } catch (SQLException ex) {
            //JOptionPane.showMessageDialog(null, "Erro ao cadastrar Cliente", "Erro", 0);
        }
    }

    public ArrayList<Cliente> getAllClientes() throws SQLException {
        try {
            return (ClienteDAO.getInstance()).findAll();
        } catch (SQLException ex) {

        }
        terminar();
        return null;
    }

    private void terminar() {
        MySqlDAO.terminar();
    }

}
