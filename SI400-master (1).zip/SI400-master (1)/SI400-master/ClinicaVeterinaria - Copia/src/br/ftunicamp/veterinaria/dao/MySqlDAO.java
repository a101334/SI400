/*
 * Disciplina: Programação Orientada Objetos 2 
 * Prof.Dr.Ivan Ricarte
 * Curso: Tec.Análise e Desenvolvimento de Sistemas
 */

package br.ftunicamp.veterinaria.dao;

import java.sql.*;
import com.mysql.jdbc.Statement;

/**
 *
 * @author AmadeuCarvalho
 */
public class MySqlDAO {

    public static final String DRIVER = "com.mysql.jdbc.Driver";
    public static final String DBURL = "jdbc:mysql://localhost:3306/FT_UNICAMP";
    private static Connection con;
    private static final String USER = "root";
    private static final String PASWORD = "figurante";
    // metodo para criar a conexao com MySQL

    public static Connection getConnection() {
        if (con == null) {
            try {
                Class.forName(DRIVER).newInstance();
                con = DriverManager.getConnection(DBURL, USER,
                        PASWORD);
            } catch (Exception e) {
                System.err.println("Exception: " + e.getMessage());
            }
        }
        return con;
    }

    public static ResultSet getResultSet(String query) {
        Statement s;
        ResultSet rs = null;
        try {
            s = (Statement) con.createStatement();
            s.executeQuery(query);
            rs = s.getResultSet();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public static int executeUpdate(String query) {
        Statement st;
        int update = 0;
        try {
            st = (Statement) con.createStatement();
            update = st.executeUpdate(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return update;
    }

    public static void terminar() {
        try {
            (MySqlDAO.getConnection()).close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
