/*
 * Disciplina: Programação Orientada Objetos 2 
 * Prof.Dr.Ivan Ricarte
 * Curso: Tec.Análise e Desenvolvimento de Sistemas
 */

package br.ftunicamp.veterinaria.dao;

import br.ftunicamp.veterinaria.model.Cliente;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author AmadeuCarvalho
 */
public class ClienteDAO {
    
     private static ClienteDAO instance;

    private ClienteDAO() {
        MySqlDAO.getConnection();
    }

    public static ClienteDAO getInstance() throws SQLException {
        if (instance == null) {
            instance = new ClienteDAO();
        }
        return instance;
    }

    public void insertCliente(String nome,String cpf, String endereco, String telefone, String cep, String email) {
        MySqlDAO.executeUpdate("INSERT INTO Cliente (NOME,CPF ,ENDERECO, TELEFONE, CEP, EMAIL) VALUES('" + nome + "'  ,'" + cpf + "','"  + endereco + "'  ,'" + telefone + "' ,'" + cep + "' ,'" + email + "')");
    }
    
        public ArrayList<Cliente> findAll() {
        ArrayList<Cliente> clientes = new ArrayList<>();
        ResultSet rs = null;
        try {
            rs = MySqlDAO.getResultSet("SELECT * FROM CLIENTE");
            while (rs.next()) {
                clientes.add(new Cliente(rs.getInt("id_cliente"), rs.getString("nome"),rs.getString("cpf"), rs.getString("endereco"),
                        rs.getString("telefone"), rs.getString("cep"), rs.getString("email")));
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clientes;
    }
}
