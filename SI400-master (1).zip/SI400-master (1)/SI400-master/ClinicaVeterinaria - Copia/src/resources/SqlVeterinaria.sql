/*
 * Disciplina: Programação Orientada Objetos 2 
 * Prof.Dr.Ivan Ricarte
 * Curso: Tec.Análise e Desenvolvimento de Sistemas
 */

/* >>>>>>>>> Definindo banco <<<<<<<<<<<< */

CREATE DATABASE FT_UNICAMP;
USE FT_UNICAMP;


/* >>>>>>>>>>>> Drop <<<<<<<<<<<<<*/

DROP TABLE CLIENTE;


/* >>>>>>>>>>>> Create <<<<<<<<<<< */

CREATE TABLE CLIENTE (
     ID_CLIENTE INT NOT NULL AUTO_INCREMENT, 
     NOME VARCHAR(100), 
     CPF VARCHAR(15),
     ENDERECO VARCHAR(100), 
     TELEFONE VARCHAR(15),
     CEP VARCHAR(15),
     EMAIL VARCHAR (100),
     PRIMARY KEY (ID_CLIENTE)
);


/* >>>>>>>>>> Alter Table <<<<<<<<<<<<<<<< */

/* >>>>>>>>>>> Insert <<<<<<<<<<<<<<<<<<<<*/

INSERT INTO CLIENTE
VALUES(null, 'Gisele Baioco' ,'42334224387', 'Rua Rio preto n°39 Limeira/SP' , '3232-2132' , '232212-330' , 'gBaiocoBd@ft.com');

INSERT INTO CLIENTE
VALUES(null, 'Maria Jose' ,'42334224387', 'Rua Santanópolis n°57 Limeira/SP' , '3245-2342' , '197412-330' , 'mariaJose@gmail.com');

INSERT INTO CLIENTE
VALUES(null, 'Jose Maria' ,'42334224387', 'Rua Cora Coralina n°39 Campinas/SP' , '9474-3020' , '95874-920' , 'joseMaria@gmail.com');

/* >>>>>>>>>>>>>>> Update <<<<<<<<<<<<<< */


/* >>>>>>>>>>>>> Select <<<<<<<<<<<<<<*/ 
SELECT * FROM CLIENTE;


